#ifndef PROCEDURAL_H
#define PROCEDURAL_H

void readNumbers(int ary[],int size);
void printNumbers(int ary[],int size);
int sum(int ary[],int size);
double average(int ary[],int size);
int max(int ary[],int size);

#endif