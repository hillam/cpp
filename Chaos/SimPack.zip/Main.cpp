#include "SimApp.h"
#include <gtk/gtk.h>
#include <iostream>

using namespace std;

int main(int argc, char* argv[])
{	
	SimApp(argc, argv, "Particle Simulator", 500, 600);
}

